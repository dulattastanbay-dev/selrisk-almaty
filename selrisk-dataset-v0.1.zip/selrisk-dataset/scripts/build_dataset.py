"""Build real-data, positive-unlabeled SelRisk tables. No synthetic fallback."""
from __future__ import annotations
import argparse, concurrent.futures, hashlib, json, math, shutil, time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import requests

ROOT = Path(__file__).resolve().parents[1]
START, END, WARMUP = '2016-01-01', '2023-12-31', '2015-12-01'
TZ = 'Etc/GMT-6'
POINTS = [
    ('kishi_almaty', 'Киши Алматы / Малая Алматинка', 43.10, 77.08),
    ('ulken_almaty', 'Улкен Алматы / Большая Алматинка', 43.08, 76.98),
    ('left_talgar', 'Левый Талгар', 43.10, 77.25),
]
ARCHIVE = 'https://archive-api.open-meteo.com/v1/archive'
USGS = 'https://earthquake.usgs.gov/fdsnws/event/1/query'
COOLR = 'https://gis.earthdata.nasa.gov/portal/rest/services/Landslides/COOLR_Reports_Points/FeatureServer/0/query'
DAILY = 'temperature_2m_mean,temperature_2m_min,temperature_2m_max,precipitation_sum,rain_sum,snowfall_sum'
FEATURES = [
    'latitude', 'longitude', 'temperature_mean_lag1_c', 'temperature_min_lag1_c',
    'temperature_max_lag1_c', 'temperature_mean_prev7d_c', 'precipitation_lag1_mm',
    'precipitation_prev3d_mm', 'precipitation_prev7d_mm', 'precipitation_prev14d_mm',
    'rain_lag1_mm', 'snowfall_lag1_cm', 'soil_moisture_lag1_m3_m3',
    'snow_depth_lag1_m', 'snow_depth_change_prev1d_m', 'earthquake_count_prev7d',
    'earthquake_max_magnitude_prev7d', 'earthquake_nearest_prev7d_km',
    'day_of_year_sin', 'day_of_year_cos',
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def fetch(key, url, params, raw, refresh):
    path = raw / f'{key}.json'
    if path.exists() and not refresh:
        data = json.loads(path.read_text())
    else:
        for attempt in range(4):
            try:
                response = requests.get(url, params=params, timeout=180)
                response.raise_for_status()
                data = response.json()
                if data.get('error'):
                    raise RuntimeError(data['error'])
                path.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
                (raw / f'{key}.request.json').write_text(json.dumps({
                    'url': response.url,
                    'retrieved_utc': datetime.now(timezone.utc).isoformat(),
                }, ensure_ascii=False), encoding='utf-8')
                break
            except (requests.RequestException, ValueError, RuntimeError):
                if attempt == 3:
                    raise
                time.sleep(4 * (attempt + 1))
    if data.get('error'):
        raise RuntimeError(f'{key}: source API returned an error')
    if data.get('exceededTransferLimit'):
        raise RuntimeError('COOLR truncated: paginate before using these results')
    if key == 'earthquakes' and len(data.get('features', [])) >= 20000:
        raise RuntimeError('USGS result limit reached: paginate or subdivide query')
    return key, data

def haversine(lat1, lon1, lat2, lon2):
    a, b = np.radians(lat1), np.radians(lat2)
    dl = np.radians(lon2 - lon1)
    return 6371.0088 * 2 * np.arcsin(np.sqrt(np.clip(
        np.sin((b-a)/2)**2 + np.cos(a)*np.cos(b)*np.sin(dl/2)**2, 0, 1)))

def write_csv(frame, path):
    frame.to_csv(path, index=False, encoding='utf-8', float_format='%.6f', na_rep='')

def build(raw, refresh=False):
    raw.mkdir(parents=True, exist_ok=True)
    out, meta = ROOT / 'data', ROOT / 'metadata'
    out.mkdir(exist_ok=True); meta.mkdir(exist_ok=True)
    jobs = []
    for i, (_, _, lat, lon) in enumerate(POINTS):
        common = dict(latitude=lat, longitude=lon, start_date=WARMUP, end_date=END, timezone=TZ)
        jobs.append((f'weather_{i}', ARCHIVE, dict(**common, models='era5', daily=DAILY,
                    hourly='soil_moisture_0_to_7cm'), raw, refresh))
        jobs.append((f'snow_{i}', ARCHIVE, dict(**common, models='era5_land',
                    hourly='snow_depth'), raw, refresh))
    jobs += [
        ('earthquakes', USGS, dict(format='geojson', starttime=WARMUP, endtime='2024-01-01',
         latitude=43.14, longitude=77.025, maxradiuskm=150, minmagnitude=3,
         orderby='time-asc', limit=20000), raw, refresh),
        ('coolr', COOLR, dict(f='json', where='1=1', geometry='76.7,43.0,77.35,43.28',
         geometryType='esriGeometryEnvelope', inSR=4326, spatialRel='esriSpatialRelIntersects',
         outFields='*', returnGeometry='true', resultRecordCount=1000), raw, refresh),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        loaded = dict(pool.map(lambda args: fetch(*args), jobs))
    days = pd.date_range(START, END)
    eq_rows = []
    for feature in loaded['earthquakes']['features']:
        p, coordinates = feature['properties'], feature['geometry']['coordinates']
        if p.get('type') != 'earthquake':
            continue
        eq_rows.append(dict(event_id=feature['id'], time_utc=pd.to_datetime(p['time'], unit='ms', utc=True),
            latitude=coordinates[1], longitude=coordinates[0], depth_km=coordinates[2],
            magnitude=p['mag'], magnitude_type=p.get('magType'), source_url=p['url']))
    eq = pd.DataFrame(eq_rows, columns=['event_id','time_utc','latitude','longitude','depth_km',
                                      'magnitude','magnitude_type','source_url'])
    if not eq.empty:
        eq = eq.sort_values(['time_utc', 'event_id']).reset_index(drop=True)
        eq['time_utc'] = pd.to_datetime(eq['time_utc'], utc=True)
    write_csv(eq, out / 'earthquakes.csv')
    nasa = []
    for feature in loaded['coolr']['features']:
        a = feature['attributes']
        nasa.append(dict(event_id='NASA_'+str(a['event_id']),
            event_date=pd.to_datetime(a['event_date'], unit='ms', utc=True).strftime('%Y-%m-%d'),
            category=a['landslide_category'], trigger=a['landslide_trigger'], latitude=a['latitude'],
            longitude=a['longitude'], location_accuracy=a['location_accuracy'],
            source_url=a['source_link'], catalogue_url=COOLR.rsplit('/query',1)[0]))
    write_csv(pd.DataFrame(nasa), out / 'nasa_catalogue.csv')
    manual = pd.read_csv(meta / 'events.csv', dtype={'event_id':str}).fillna('')
    parts, observations, locations = [], [], []
    for i, (loc, label, lat, lon) in enumerate(POINTS):
        weather, snow = loaded[f'weather_{i}'], loaded[f'snow_{i}']
        if weather['utc_offset_seconds'] != 21600 or snow['utc_offset_seconds'] != 21600:
            raise ValueError('Unexpected day boundary; UTC+6 is required for 2016–2023')
        daily = pd.DataFrame(weather['daily']).rename(columns={'time':'date'})
        daily['date'] = pd.to_datetime(daily['date'])
        daily = daily.set_index('date').sort_index()
        h = pd.DataFrame(weather['hourly']); h['time'] = pd.to_datetime(h['time'])
        s = pd.DataFrame(snow['hourly']); s['time'] = pd.to_datetime(s['time'])
        h, s = h.set_index('time'), s.set_index('time')
        if (h.resample('D').size() != 24).any() or (s.resample('D').size() != 24).any():
            raise ValueError('Incomplete hourly day')
        daily['soil_moisture_mean_m3_m3'] = h['soil_moisture_0_to_7cm'].resample('D').mean()
        daily['snow_depth_mean_m'] = s['snow_depth'].resample('D').mean()
        if daily.isna().any().any():
            raise ValueError('Missing raw values: stop instead of filling or simulating')
        obs = daily.loc[START:END].reset_index()
        obs.insert(1, 'location_id', loc)
        obs['date'] = obs['date'].dt.strftime('%Y-%m-%d')
        observations.append(obs)
        x = pd.DataFrame(index=daily.index)
        for src, dst in [('temperature_2m_mean','temperature_mean_lag1_c'),
            ('temperature_2m_min','temperature_min_lag1_c'), ('temperature_2m_max','temperature_max_lag1_c'),
            ('precipitation_sum','precipitation_lag1_mm'), ('rain_sum','rain_lag1_mm'),
            ('snowfall_sum','snowfall_lag1_cm'), ('soil_moisture_mean_m3_m3','soil_moisture_lag1_m3_m3'),
            ('snow_depth_mean_m','snow_depth_lag1_m')]:
            x[dst] = daily[src].shift(1)
        for n in [3,7,14]:
            x[f'precipitation_prev{n}d_mm'] = daily['precipitation_sum'].shift(1).rolling(n, min_periods=n).sum()
        x['temperature_mean_prev7d_c'] = daily['temperature_2m_mean'].shift(1).rolling(7,min_periods=7).mean()
        x['snow_depth_change_prev1d_m'] = daily['snow_depth_mean_m'].shift(1)-daily['snow_depth_mean_m'].shift(2)
        x = x.loc[START:END].copy()
        x['location_id'], x['latitude'], x['longitude'] = loc, lat, lon
        counts, maxmag, nearest = [], [], []
        for day in x.index:
            cutoff = pd.Timestamp(day).tz_localize(TZ).tz_convert('UTC')
            recent = eq[(eq['time_utc'] >= cutoff-pd.Timedelta(days=7)) & (eq['time_utc'] < cutoff)]
            counts.append(len(recent))
            maxmag.append(recent['magnitude'].max() if len(recent) else np.nan)
            nearest.append(float(haversine(lat,lon,recent['latitude'].to_numpy(),
                           recent['longitude'].to_numpy()).min()) if len(recent) else np.nan)
        x['earthquake_count_prev7d'] = counts
        x['earthquake_max_magnitude_prev7d'] = maxmag
        x['earthquake_nearest_prev7d_km'] = nearest
        x['day_of_year_sin'] = np.sin(2*math.pi*(x.index.dayofyear-1)/366)
        x['day_of_year_cos'] = np.cos(2*math.pi*(x.index.dayofyear-1)/366)
        x['feature_window_end_local'] = (x.index-pd.Timedelta(days=1)).strftime('%Y-%m-%dT23:59:59+06:00')
        x['split'] = np.where(x.index.year <= 2020, 'train', np.where(x.index.year == 2021, 'validation', 'test'))
        x['event_id'], x['event_type'], x['event_source_url'] = '', '', ''
        x['target'] = pd.Series(pd.NA, index=x.index, dtype='Int64')
        x['label_status'] = 'unlabeled'
        for _, event in manual[(manual['location_id'] == loc) & (manual['join_status'] == 'included_basin_day')].iterrows():
            day = pd.Timestamp(event['event_date'])
            x.loc[day,['target','label_status','event_id','event_type','event_source_url']] = [
                1,'confirmed_basin_event',event['event_id'],event['event_type'],event['source_url']]
        x = x.reset_index(names='date')
        x['date'] = x['date'].dt.strftime('%Y-%m-%d')
        x = x[['date','location_id']+FEATURES+['feature_window_end_local','split','target',
                         'label_status','event_id','event_type','event_source_url']]
        parts.append(x)
        locations.append(dict(location_id=loc, basin_name=label, reference_latitude=lat,
            reference_longitude=lon, reference_point_origin='analyst_selected_weather_query_not_event_coordinates',
            weather_grid_latitude=weather['latitude'], weather_grid_longitude=weather['longitude'],
            weather_api_downscaling_elevation_m=weather['elevation'], weather_model='ERA5',
            snow_grid_latitude=snow['latitude'], snow_grid_longitude=snow['longitude'], snow_model='ERA5-Land',
            timezone=TZ, label_resolution='named_basin_day_not_point_or_polygon',
            spatial_warning='No verified basin polygons; reference point is not a basin average'))
    model = pd.concat(parts,ignore_index=True).sort_values(['date','location_id']).reset_index(drop=True)
    obs = pd.concat(observations,ignore_index=True).sort_values(['date','location_id']).reset_index(drop=True)
    model[FEATURES] = model[FEATURES].round(6)
    obs[obs.select_dtypes('number').columns] = obs.select_dtypes('number').round(6)
    write_csv(model, out / 'model_dataset.csv')
    model.to_parquet(out / 'model_dataset.parquet', index=False)
    write_csv(obs, out / 'daily_observations.csv')
    write_csv(pd.DataFrame(locations), meta / 'locations.csv')
    checks = {
        'unique_date_location': not model.duplicated(['date','location_id']).any(),
        'expected_row_count': len(model) == len(days)*len(POINTS),
        'all_calendar_days_present': all(len(v)==len(days) for _,v in model.groupby('location_id')),
        'no_fabricated_negatives': not model['target'].eq(0).any(),
        'target_only_positive_or_null': set(model['target'].dropna().astype(int)) == {1},
        'confirmed_positive_count_matches_events': int(model['target'].eq(1).sum()) == int(manual['join_status'].eq('included_basin_day').sum()),
        'nonnegative_precipitation': bool((obs['precipitation_sum']>=0).all()),
        'soil_moisture_valid': bool(obs['soil_moisture_mean_m3_m3'].between(0,1).all()),
        'nonnegative_snow': bool((obs['snow_depth_mean_m']>=0).all()),
        'core_features_not_missing': not model[[c for c in FEATURES if c not in ['earthquake_max_magnitude_prev7d','earthquake_nearest_prev7d_km']]].isna().any().any(),
        'lag1_matches_observations': all(np.allclose(
            model[(model.location_id==loc)&(model.date>START)]['precipitation_lag1_mm'],
            obs[(obs.location_id==loc)&(obs.date<END)]['precipitation_sum']) for loc,_,_,_ in POINTS),
    }
    if not all(checks.values()):
        raise AssertionError(checks)
    quality = dict(status='passed', checks=checks, rows=len(model), columns=len(model.columns),
        locations=len(POINTS), start_date=START, end_date=END,
        positives=int(model['target'].eq(1).sum()), confirmed_negative_count=0,
        unlabeled=int(model['target'].isna().sum()), independent_positive_dates=int(model.loc[model.target.eq(1),'date'].nunique()),
        earthquake_count=len(eq), nasa_catalogue_count=len(nasa),
        split_counts=model.groupby('split').size().to_dict(),
        split_positive_counts=model.groupby('split')['target'].sum().astype(int).to_dict(),
        limitations=['No confirmed negatives; not ready for ordinary binary classification.',
            'Training split has no joined positive events. Do not report classifier metrics.',
            'Three reference points, not catchment averages or fine-resolution hazard cells.',
            'Two reference points share one ERA5 grid cell; weather is spatially dependent.',
            'Three positive basin records on 2023-07-21 belong to one regional weather episode.',
            'Retrospective reanalysis and revised earthquake catalogue are not a real-time backtest.',
            'Snow depth change is not a measured snowmelt flux; no DEM terrain features included.'])
    (meta/'quality_report.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    source_manifest=[]
    for path in sorted(raw.glob('*.request.json')):
        record=json.loads(path.read_text()); key=path.name.removesuffix('.request.json')
        record.update(source_key=key, raw_sha256=sha(raw/f'{key}.json'))
        source_manifest.append(record)
    (meta/'source_manifest.json').write_text(json.dumps(source_manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    export = dict(id='selrisk-almaty-v0.1', data_status='experimental_positive_unlabeled',
        period=[START,END], rows=len(model), columns=len(model.columns), feature_columns=FEATURES,
        exclude_from_features=['date','location_id','feature_window_end_local','split','target','label_status',
                               'event_id','event_type','event_source_url'],
        data_files={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()},
        synthetic_data=False, label_unit='named_basin_day', weather_unit='reference_point_day',
        target='Known debris flow in named basin during date; 1 or null, never assumed zero',
        operational_availability_warning='Lagging prevents event-day lookahead but not publication/reanalysis availability leakage')
    (meta/'dataset_manifest.json').write_text(json.dumps(export,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(quality,ensure_ascii=False,indent=2))
    return model

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--raw-dir',type=Path,default=ROOT/'.cache/raw')
    parser.add_argument('--refresh',action='store_true')
    args=parser.parse_args()
    build(args.raw_dir,args.refresh)
