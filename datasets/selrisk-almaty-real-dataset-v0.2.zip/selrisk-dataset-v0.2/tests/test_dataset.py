import sys
import json
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from shapely.geometry import shape

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from build import date_info


@pytest.mark.parametrize("raw,precision",[
    ("4.05.2009","day"),("22.04.2017 ","day"),("26-27.06.1988","day_interval"),
    ("31.03-01.04.1989","day_interval"),("1982","year"),("August 1983","month"),
    ("8/1/1983 12:00:00 AM","multiple_or_unresolved"),
    ("16, 18, 19.07, 29, 30.08.1973","multiple_or_unresolved"),
    ("XVIII (2nd half of Century)","multiple_or_unresolved"),(None,"missing")])
def test_date_precision(raw,precision):
    assert date_info(raw)[2]==precision


@pytest.mark.parametrize("name",[
    "model_dynamic_power","model_regional_power","model_dynamic_era5",
    "model_regional_stations","spatial_pu_grid"])
def test_no_invented_negatives(name):
    d=pd.read_parquet(ROOT/f"data/{name}.parquet")
    assert set(d.target.dropna().unique())=={1}
    assert d.target.isna().any()
    if "date" in d:
        keys=["date"]+(["location_id"] if "location_id" in d else [])
        assert not d.duplicated(keys).any()
        assert not d.groupby("date").split.nunique().gt(1).any()


def test_catalogue_preserves_every_source_record():
    raw=json.loads((ROOT/"sources/reading_events.json").read_text())
    d=pd.read_parquet(ROOT/"data/event_catalogue.parquet")
    assert len(d[d.source_id.eq("reading_events")])==len(raw["features"])==488
    assert len(d)==492
    assert d.event_id.is_unique
    assert not d.loc[d.date_year_conflict,"exact_date_eligible"].any()
    assert not d.loc[d.date_precision.ne("day"),"exact_date_eligible"].any()


def test_weather_windows_use_only_past():
    w=pd.read_parquet(ROOT/"data/weather_power_daily.parquet").set_index("date")
    p=pd.read_parquet(ROOT/"data/model_regional_power.parquet").set_index("date")
    assert w.precipitation_mm.ge(0).all()
    for day in pd.to_datetime(["1981-05-20","1990-08-15","2005-07-01","2020-07-21"]):
        assert np.isclose(p.loc[day,"precipitation_lag2utc_mm"],w.loc[day-pd.Timedelta(days=2),"precipitation_mm"])
        expected=w.loc[day-pd.Timedelta(days=15):day-pd.Timedelta(days=2),"precipitation_mm"].sum()
        assert np.isclose(p.loc[day,"precipitation_prev14d_mm"],expected)
    cutoff=pd.to_datetime(p.feature_window_end_utc,utc=True).dt.tz_localize(None)
    assert (cutoff < p.index).all()


def test_noaa_quality_and_units():
    d=pd.read_parquet(ROOT/"data/weather_noaa_observations.parquet")
    assert d.loc[~d.qa_passed,"value"].isna().all()
    assert d.loc[d.qa_passed,"quality_flag"].eq("").all()
    q=d[d.qa_passed & d.element.eq("PRCP")]
    assert np.allclose(q.value,q.raw_value/10)
    assert q.value.ge(0).all()
    assert not d.duplicated(["date","station_id","element"]).any()
    # Validate an original day directly against the fixed-width source.
    line=(ROOT/"sources/noaa/KZ000036889.dly").read_text().splitlines()[0]
    q=d[(d.station_id=="KZ000036889")&d.element.eq("PRCP")&d.date.eq(pd.Timestamp("1936-10-02"))]
    assert q.iloc[0].raw_value==int(line[29:34])==27
    assert not d.loc[d.date.gt(pd.Timestamp("2026-11-14")),"qa_passed"].any()


def test_polygons_and_terrain():
    features=json.loads((ROOT/"data/mudflow_centers.geojson").read_text())["features"]
    assert len(features)==152
    for f in features:
        s=shape(f["geometry"])
        assert s.is_valid and not s.is_empty
        x0,y0,x1,y1=s.bounds
        assert 60<x0<x1<85 and 35<y0<y1<50
    import rasterio
    with rasterio.open(ROOT/"data/terrain_90m_utm43n.tif") as r:
        assert str(r.crs)=="EPSG:32643"
        a=r.read()
        assert np.isfinite(a).all()
        assert a[0].max()>3500
        assert (a[1]>=0).all() and (a[1]<=90).all()
        assert np.allclose(a[2]**2+a[3]**2,1,atol=1e-5)


def test_feature_allowlist_no_leakage():
    allow=json.loads((ROOT/"metadata/feature_allowlist.json").read_text())
    denied=["target","event","label","source","split","date_uncertainty"]
    for key,cols in allow.items():
        assert all(not any(term in c for term in denied) for c in cols)
        d=pd.read_parquet(ROOT/f"data/model_{key}.parquet")
        assert set(cols)<=set(d.columns)


def test_era5_does_not_reassign_talgar_basin_to_left_talgar():
    d=pd.read_parquet(ROOT/"data/model_dynamic_era5.parquet")
    talgar=d[d.location_id.eq("left_talgar")]
    ids=";".join(talgar.event_id.dropna())
    assert "READING_" not in ids


def test_glof_is_separate():
    h=pd.read_parquet(ROOT/"data/glof_kazakhstan_supplement.parquet")
    assert h.Country.str.contains("Kazakh",case=False).all()
    d=pd.read_parquet(ROOT/"data/event_catalogue.parquet")
    assert not d.source_id.eq("hma_glof").any()


def test_compatibility_headers_and_labels():
    old=pd.read_csv(ROOT/"sources/legacy_model_dataset.csv")
    new=pd.read_parquet(ROOT/"data/model_dataset.parquet")
    assert old.columns.tolist()==new.columns.tolist()
    assert len(new.columns)==29 and len(new)==len(old)==8766
    assert new.target.eq(1).sum()==6


def test_intervals_and_geographic_bounds():
    d=pd.read_parquet(ROOT/"data/event_catalogue.parquet")
    dated=d.dropna(subset=["date_start","date_end"])
    assert (dated.date_start<=dated.date_end).all()
    located=d.dropna(subset=["longitude","latitude"])
    assert located.longitude.between(60,90).all()
    assert located.latitude.between(35,50).all()


def test_regional_weather_is_not_basin_specific():
    d=pd.read_parquet(ROOT/"data/model_dynamic_power.parquet")
    for c in ["precipitation_prev14d_mm","temperature_mean_lag2utc_c"]:
        assert not d.groupby("date")[c].nunique().gt(1).any()
    regional=pd.read_parquet(ROOT/"data/model_regional_power.parquet")
    dates=set(d.loc[d.target.eq(1),"date"])
    assert set(regional.loc[regional.target.eq(1),"date"])==dates
    assert d.loc[d.target.eq(1),"feature_complete"].all()
