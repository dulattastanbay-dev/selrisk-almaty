"""Supplementary catalogue, exhaustive schemas, package inventory and hashes."""
import hashlib
import json
import platform
from importlib.metadata import version
import pandas as pd
import numpy as np
from build import ROOT, SRC, DATA, META, save


def main():
    # The development CSV contains Windows-1252 punctuation; preserve raw bytes.
    h=pd.read_csv(SRC/"HMAGLOFDB.csv",encoding="cp1252")
    h=h[h.Country.str.contains("Kazakh",case=False,na=False)].copy()
    h["source_id"]="hma_glof"
    h["source_url"]="https://github.com/fidelsteiner/HMAGLOFDB"
    h["source_commit"]="18d9d336e8e152053ee78246781cc37d510194c7"
    h["training_use"]="supplement_only_not_merged_GLOF_not_automatically_DF"
    save(h,"glof_kazakhstan_supplement")
    schemas=[]
    for p in sorted(DATA.glob("*.parquet")):
        d=pd.read_parquet(p)
        for c in d:
            schemas.append(dict(table=p.stem,column=c,dtype=str(d[c].dtype),
                missing=int(d[c].isna().sum()),example=str(d[c].dropna().iloc[0]) if d[c].notna().any() else ""))
    pd.DataFrame(schemas).to_csv(META/"schema.csv",index=False)
    import rasterio
    with rasterio.open(DATA/"terrain_90m_utm43n.tif") as f:
        terrain=dict(crs=str(f.crs),width=f.width,height=f.height,resolution_m=list(f.res),
            bands=list(f.descriptions),finite_fraction=float(np.isfinite(f.read(1)).mean()),
            elevation_min_m=float(np.nanmin(f.read(1))),elevation_max_m=float(np.nanmax(f.read(1))))
    grid=pd.read_parquet(DATA/"spatial_pu_grid.parquet")
    base=json.loads((META/"quality_report.json").read_text())
    base["noaa"]=json.loads((META/"noaa_quality_report.json").read_text())
    base["glof_kazakhstan_supplement_rows"]=len(h)
    base["terrain"]=terrain
    base["spatial_grid"]=dict(rows=len(grid),mapped_membership_positives=int(grid.target.eq(1).sum()),
                            unknown=int(grid.target.isna().sum()),block_count=int(grid.spatial_block_id.nunique()))
    p=pd.read_parquet(DATA/"event_catalogue.parquet")
    base["selected_data_year_coverage"]={"noaa_training":"1937-1991","power_training":"1981-2020",
                                       "era5_training":"2016-2023"}
    base["point_coordinate_missing_records"]=int(p.longitude.isna().sum())
    polys=json.loads((DATA/"mudflow_centers.geojson").read_text())["features"]
    base["repaired_polygon_ids"]=[f["properties"]["center_id"] for f in polys if not f["properties"]["source_geometry_valid"]]
    (META/"quality_report.json").write_text(json.dumps(base,ensure_ascii=False,indent=2))
    packages=["pandas","numpy","requests","pyarrow","pyproj","shapely","rasterio","Pillow","pytest"]
    (META/"environment.json").write_text(json.dumps(dict(python=platform.python_version(),
                                packages={p:version(p) for p in packages}),indent=2))
    # All source files, including legacy and supplements, are fingerprinted.
    manifest=[]
    for p in sorted(SRC.rglob("*")):
        if p.is_file():
            manifest.append(dict(file=str(p.relative_to(ROOT)),bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    (META/"raw_file_hashes.json").write_text(json.dumps(manifest,indent=2))
    paths=[p for p in sorted(ROOT.rglob("*")) if p.is_file()
           and "__pycache__" not in str(p) and ".pytest_cache" not in str(p)
           and p.name!="checksums.sha256"]
    (ROOT/"checksums.sha256").write_text("".join(
        hashlib.sha256(p.read_bytes()).hexdigest()+"  "+str(p.relative_to(ROOT))+"\n" for p in paths))
    print("Finalized",len(paths),"files; supplementary GLOF rows",len(h))


if __name__=="__main__":
    main()
