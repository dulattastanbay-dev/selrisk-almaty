"""Download public sources with an auditable ledger; never synthesize failures."""
from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import argparse
import requests

ROOT = Path(__file__).resolve().parents[1]
S = ROOT / "sources"
LEDGER = ROOT / "metadata/downloads.json"


def download(key, url, name):
    p = S / name
    ledger = json.loads(LEDGER.read_text()) if LEDGER.exists() else {}
    if not p.exists():
        r = requests.get(url, timeout=240)
        r.raise_for_status()
        if name.endswith(".json"):
            payload = r.json()
            if payload.get("error"):
                raise RuntimeError(payload)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(r.content)
        retrieved = datetime.now(timezone.utc).isoformat()
    else:
        retrieved = ledger.get(key, {}).get("retrieved_utc", "2026-11-14 (initial download; exact timestamp not retained)")
    ledger[key] = dict(url=url, file=str(p.relative_to(ROOT)), retrieved_utc=retrieved,
                       sha256=hashlib.sha256(p.read_bytes()).hexdigest(), bytes=p.stat().st_size)
    LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2))
    print(key, p.stat().st_size, flush=True)
    return p


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", choices=["weather", "catalogue", "noaa"])
    args = parser.parse_args()
    if args.source == "weather":
        # One regional series, not three pretend-independent basin series.
        # POWER precipitation begins Jan 1981. First 14 days lack a full window.
        for start, end in [(19810101, 20001231), (20010101, 20251231)]:
            url = ("https://power.larc.nasa.gov/api/temporal/daily/point"
                   "?parameters=PRECTOTCORR,T2M,T2M_MIN,T2M_MAX&community=AG"
                   f"&longitude=77.08&latitude=43.1&start={start}&end={end}"
                   "&format=JSON&time-standard=UTC")
            download(f"power_{start}_{end}", url, f"power_{start}_{end}.json")
    elif args.source == "noaa":
        download("ghcnd_stations", "https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt",
                 "ghcnd-stations.txt")
        download("ghcnd_readme", "https://www.ncei.noaa.gov/pub/data/ghcn/daily/readme.txt",
                 "ghcnd_readme.txt")
        for station in ["KZ000036870","KZ000036879","KZ000036889","KZ000036884","KZ000036887"]:
            download(station, f"https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/{station}.dly",
                     f"noaa/{station}.dly")
    else:
        urls = {
            "reading_events": "https://services1.arcgis.com/PhkL97KbkzUBf4PQ/arcgis/rest/services/Platform/FeatureServer/0/query?where=1%3D1&outFields=*&returnGeometry=true&outSR=4326&f=pjson&resultRecordCount=2000",
            "reading_service": "https://services1.arcgis.com/PhkL97KbkzUBf4PQ/arcgis/rest/services/Platform/FeatureServer/0?f=pjson",
            "reading_map": "https://www.arcgis.com/sharing/rest/content/items/1c3a2f558aa94242b0b0994b893bde45/data?f=pjson",
            "reading_item": "https://www.arcgis.com/sharing/rest/content/items/c7348d7a2a2348a9bd11a2ce338aee9a?f=pjson",
        }
        for key, url in urls.items():
            download(key, url, key + ".json")


if __name__ == "__main__":
    main()
