#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/build.py
python scripts/terrain.py
python scripts/noaa.py
python scripts/finalize.py
python -m pytest -q tests
