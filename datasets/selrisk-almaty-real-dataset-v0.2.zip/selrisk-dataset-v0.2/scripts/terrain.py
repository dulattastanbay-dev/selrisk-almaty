"""Real Terrain Tiles -> projected 90 m DEM, derivatives and PU spatial grid."""
import io
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_origin
from rasterio.warp import reproject, Resampling, transform_bounds
from rasterio.features import rasterize
from PIL import Image
from pyproj import Transformer

from acquire import ROOT, download

BBOX = (76.70, 43.00, 77.35, 43.28)
CRS = "EPSG:32643"


def tile(lon, lat, z):
    return ((lon + 180) / 360 * 2**z,
            (1 - math.asinh(math.tan(math.radians(lat))) / math.pi) / 2 * 2**z)


def main():
    z = 11
    x0, y0 = tile(BBOX[0], BBOX[3], z)
    x1, y1 = tile(BBOX[2], BBOX[1], z)
    x0, y0, x1, y1 = map(math.floor, (x0, y0, x1, y1))
    dem = np.full(((y1-y0+1)*256, (x1-x0+1)*256), np.nan, np.float32)
    for y in range(y0, y1+1):
        for x in range(x0, x1+1):
            url = f"https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png"
            p = download(f"terrain_{z}_{x}_{y}", url, f"terrain/{z}_{x}_{y}.png")
            a = np.asarray(Image.open(p).convert("RGB"), np.float32)
            h = a[:,:,0]*256 + a[:,:,1] + a[:,:,2]/256 - 32768
            dem[(y-y0)*256:(y-y0+1)*256, (x-x0)*256:(x-x0+1)*256] = h
    half = math.pi * 6378137
    res = 2*half/(2**z*256)
    src_transform = from_origin(-half+x0*256*res, half-y0*256*res, res, res)
    left, bottom, right, top = transform_bounds("EPSG:4326", CRS, *BBOX, densify_pts=21)
    tr = from_origin(left, top, 90, 90)
    width, height = math.ceil((right-left)/90), math.ceil((top-bottom)/90)
    dst = np.full((height, width), np.nan, np.float32)
    reproject(dem, dst, src_transform=src_transform, src_crs="EPSG:3857",
              dst_transform=tr, dst_crs=CRS, dst_nodata=np.nan, resampling=Resampling.bilinear)
    gy, gx = np.gradient(dst, -90, 90)
    slope = np.degrees(np.arctan(np.hypot(gx, gy)))
    # Downslope azimuth, clockwise from north. Not geomorphological susceptibility.
    az = np.arctan2(-gx, -gy)
    vals = [dst, slope, np.sin(az), np.cos(az)]
    names = ["elevation_m", "slope_deg", "aspect_sin", "aspect_cos"]
    path = ROOT / "data/terrain_90m_utm43n.tif"
    with rasterio.open(path, "w", driver="GTiff", width=width, height=height,
                       count=4, dtype="float32", crs=CRS, transform=tr,
                       nodata=np.nan, compress="deflate") as out:
        for i, (v, name) in enumerate(zip(vals,names), 1):
            out.write(v.astype("float32"), i)
            out.set_band_description(i, name)
    polygons = json.loads((ROOT/"data/mudflow_centers.geojson").read_text())["features"]
    from shapely.geometry import shape, mapping
    from shapely.ops import transform
    project = Transformer.from_crs(4326, CRS, always_xy=True).transform
    shapes = [(mapping(transform(project, shape(f["geometry"]))), 1) for f in polygons]
    mask = rasterize(shapes, out_shape=dst.shape, transform=tr, fill=0, dtype="uint8")
    # A compact 450 m sample lattice, not 90 m independent training examples.
    rr, cc = np.meshgrid(np.arange(2,height-2,5),np.arange(2,width-2,5), indexing="ij")
    xs = left+(cc.ravel()+.5)*90
    ys = top-(rr.ravel()+.5)*90
    lon, lat = Transformer.from_crs(CRS,4326,always_xy=True).transform(xs,ys)
    flat = np.column_stack([v[rr,cc].ravel() for v in vals])
    frame = pd.DataFrame(flat, columns=names)
    frame.insert(0,"longitude",lon)
    frame.insert(0,"latitude",lat)
    frame.insert(0,"sample_id",[f"grid_{r}_{c}" for r,c in zip(rr.ravel(),cc.ravel())])
    frame["within_mapped_mudflow_center"] = mask[rr,cc].ravel().astype(int)
    # Membership is an inventory observation, not proof of susceptibility or absence.
    frame["target"] = frame.within_mapped_mudflow_center.where(frame.within_mapped_mudflow_center.eq(1))
    frame["label_status"] = np.where(frame.target.eq(1), "mapped_inventory_positive", "unlabeled")
    frame["spatial_block_id"] = [f"{int(x//5000)}_{int(y//5000)}" for x,y in zip(xs,ys)]
    frame["source_id"] = "terrain_tiles;reading_map"
    frame.to_csv(ROOT/"data/spatial_pu_grid.csv",index=False,float_format="%.7f")
    frame.to_parquet(ROOT/"data/spatial_pu_grid.parquet",index=False)
    print("terrain",dst.shape,"finite",np.isfinite(dst).mean(),"spatial",len(frame),
          "mapped",frame.target.eq(1).sum())


if __name__ == "__main__":
    main()
