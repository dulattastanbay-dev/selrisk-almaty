"""Offline deterministic build. All uncertain labels remain NULL, never zero."""
from pathlib import Path
import json
import re
import calendar
import hashlib
import zipfile

import numpy as np
import pandas as pd
from pyproj import Transformer
from shapely.geometry import Polygon, mapping
from shapely.ops import transform, unary_union
from shapely import make_valid

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "sources"
DATA = ROOT / "data"
META = ROOT / "metadata"
EVENT_URL = "https://services1.arcgis.com/PhkL97KbkzUBf4PQ/arcgis/rest/services/Platform/FeatureServer/0"
MAP_URL = "https://www.arcgis.com/sharing/rest/content/items/1c3a2f558aa94242b0b0994b893bde45/data?f=pjson"
BASINS = {"Kishi Almaty":"kishi_almaty","Ulken Almaty":"ulken_almaty",
          "Aksay":"aksay","Kargaly":"kargaly"}


def save(df, name):
    df.to_csv(DATA/f"{name}.csv", index=False, float_format="%.8f")
    df.to_parquet(DATA/f"{name}.parquet",index=False)


def date_info(raw):
    s = str(raw or "").strip()
    # Strict day.month.year only. Do not guess US Excel dates.
    if re.fullmatch(r"\d{1,2}\.\d{1,2}\.\d{4}",s):
        try:
            d = pd.to_datetime(s,format="%d.%m.%Y")
            return d,d,"day"
        except ValueError:
            return pd.NaT,pd.NaT,"invalid"
    m = re.fullmatch(r"(\d{1,2})-(\d{1,2})\.(\d{1,2})\.(\d{4})",s)
    if m:
        a,b,month,year = map(int,m.groups())
        try:
            return pd.Timestamp(year,month,a),pd.Timestamp(year,month,b),"day_interval"
        except ValueError:
            return pd.NaT,pd.NaT,"invalid"
    m = re.fullmatch(r"(\d{1,2})\.(\d{1,2})-(\d{1,2})\.(\d{1,2})\.(\d{4})",s)
    if m:
        a,am,b,bm,y = map(int,m.groups())
        return pd.Timestamp(y,am,a),pd.Timestamp(y,bm,b),"day_interval"
    if re.fullmatch(r"\d{4}",s) and 1678 <= int(s) <= 2261:
        return pd.Timestamp(int(s),1,1),pd.Timestamp(int(s),12,31),"year"
    for month in ["May","August"]:
        m = re.fullmatch(fr"{month} (\d{{4}})",s)
        if m:
            y = int(m[1]); mo = 5 if month=="May" else 8
            return pd.Timestamp(y,mo,1),pd.Timestamp(y,mo,calendar.monthrange(y,mo)[1]),"month"
    return pd.NaT,pd.NaT, "multiple_or_unresolved" if s else "missing"


def catalogue():
    payload = json.loads((SRC/"reading_events.json").read_text())
    assert not payload.get("exceededTransferLimit"), "Truncated catalogue"
    rows = []
    for f in payload["features"]:
        a = f["attributes"]; g = f.get("geometry",{})
        start,end,precision = date_info(a["Date"])
        mismatch = pd.notna(start) and precision=="day" and a["Year"] is not None and start.year!=a["Year"]
        rows.append(dict(event_id=f"READING_{a['ID']}", source_fid=a["FID"],
                         source_date=a["Date"], date_start=start,date_end=end,
                         date_precision=precision,year_source=a["Year"],
                         date_year_conflict=bool(mismatch),
                         country=a["Country_"],basin=a["Basin"],center_name=a["Name"],
                         event_type=a["Type"],category_source=a["Category"],
                         reported_number_source=a["Number"],comment_source=a["Comment"],
                         damage_source=a["Damage"],discharge_source=a["Discharge"],
                         management_source=a["Management"],
                         longitude=g.get("x",a["Lon"]),latitude=g.get("y",a["Lat"]),
                         coordinate_precision="published_event_center_not_survey_accuracy",
                         source_id="reading_events",source_url=EVENT_URL,
                         exact_date_eligible=precision=="day" and not mismatch))
    df = pd.DataFrame(rows)
    keys = ["source_date","country","basin","event_type","longitude","latitude"]
    df["possible_duplicate"] = df.duplicated(keys,keep=False)
    df["dedup_keep"] = ~df.duplicated(keys,keep="first")
    legacy = pd.read_csv(SRC/"legacy_events.csv")
    extra = []
    names = {"kishi_almaty":"Kishi Almaty","ulken_almaty":"Ulken Almaty","left_talgar":"Left Talgar"}
    for a in legacy[legacy.join_status.eq("included_basin_day")].to_dict("records"):
        d = pd.Timestamp(a["event_date"])
        extra.append(dict(event_id=a["event_id"],source_date=a["event_date"],date_start=d,date_end=d,
                          date_precision="day",year_source=d.year,date_year_conflict=False,
                          country="Kazakhstan",basin=names[a["location_id"]],center_name=None,
                          event_type=a["event_type"],longitude=np.nan,latitude=np.nan,
                          coordinate_precision="named_basin_no_point",
                          source_id="kazhydromet_2023" if a["event_id"].startswith("KAZHYDRO") else "official_news",
                          source_url=a["source_url"],
                          exact_date_eligible=True,possible_duplicate=False,dedup_keep=True))
    df = pd.concat([df,pd.DataFrame(extra)],ignore_index=True)
    # These are event records; Number is preserved but never expanded.
    save(df,"event_catalogue")
    features = []
    for a in df.to_dict("records"):
        if pd.notna(a["longitude"]) and pd.notna(a["latitude"]):
            prop = {k:(v.isoformat() if isinstance(v,pd.Timestamp) else v) for k,v in a.items()}
            prop = {k:(None if pd.isna(v) else v) for k,v in prop.items()}
            features.append(dict(type="Feature",geometry=dict(type="Point",coordinates=[a["longitude"],a["latitude"]]),properties=prop))
    (DATA/"event_points.geojson").write_text(json.dumps(dict(type="FeatureCollection",features=features),ensure_ascii=False))
    return df


def polygons():
    m = json.loads((SRC/"reading_map.json").read_text())
    layer = m["operationalLayers"][0]["featureCollection"]["layers"][0]
    assert layer["layerDefinition"]["extent"]["spatialReference"]["latestWkid"]==3857
    project = Transformer.from_crs(3857,4326,always_xy=True).transform
    out = []
    for f in layer["featureSet"]["features"]:
        a=f["attributes"]
        # ArcGIS rings: outer clockwise, holes counterclockwise.
        outer=[]; holes=[]
        for ring in f["geometry"]["rings"]:
            p=Polygon(ring)
            (holes if p.exterior.is_ccw else outer).append(p)
        if not outer:  # Explicitly fail rather than silently discard geometry.
            raise ValueError(f"Missing exterior for {a['FID']}")
        geo=unary_union(outer).difference(unary_union(holes)) if holes else unary_union(outer)
        original_valid=geo.is_valid
        if not original_valid:
            geo=make_valid(geo)
        geo=transform(project,geo)
        props=dict(center_id=f"READING_CENTER_{a['FID']}",name=a["Name"],basin=a["Catchment"],
                   type_source=a["Type"],area_source_km2=a["Area_km2"],
                   length_source_m=a["Length_m"],width_source_m=a["Width_m"],
                   geometry_role="mapped_mudflow_center_NOT_catchment_boundary",
                   source_geometry_valid=original_valid,
                   geometry_repair="none" if original_valid else "shapely_make_valid",
                   survey_date=None,source_id="reading_map",source_url=MAP_URL)
        out.append(dict(type="Feature",geometry=mapping(geo),properties=props))
    (DATA/"mudflow_centers.geojson").write_text(json.dumps(dict(type="FeatureCollection",features=out),ensure_ascii=False))
    save(pd.DataFrame([f["properties"] for f in out]),"mudflow_centers_attributes")
    return len(out)


def weather():
    frames = []
    for p in sorted(SRC.glob("power_????????_????????.json")):
        obj=json.loads(p.read_text())
        assert obj["header"]["time_standard"]=="UTC"
        d=pd.DataFrame(obj["properties"]["parameter"])
        d.index=pd.to_datetime(d.index,format="%Y%m%d")
        d.index.name="date"
        d=d.replace(obj["header"]["fill_value"],np.nan)
        d["source_file"]=p.name
        frames.append(d)
    w=pd.concat(frames).sort_index()
    assert not w.index.duplicated().any()
    assert w.index.equals(pd.date_range(w.index.min(),w.index.max(),name="date"))
    w=w.rename(columns={"PRECTOTCORR":"precipitation_mm","T2M":"temperature_mean_c",
                        "T2M_MIN":"temperature_min_c","T2M_MAX":"temperature_max_c"})
    w["weather_series_id"]="power_regional_43.1_77.08"
    w["source_id"]="nasa_power"
    w["source_url"]="https://power.larc.nasa.gov/docs/services/api/temporal/daily/"
    save(w.reset_index(),"weather_power_daily")
    features=pd.DataFrame(index=w.index)
    for source,name in [("precipitation_mm","precipitation"),("temperature_mean_c","temperature_mean"),
                        ("temperature_min_c","temperature_min"),("temperature_max_c","temperature_max")]:
        unit="mm" if source=="precipitation_mm" else "c"
        features[f"{name}_lag2utc_{unit}"]=w[source].shift(2)
    for days in [3,7,14]:
        features[f"precipitation_prev{days}d_mm"]=w.precipitation_mm.shift(2).rolling(days,min_periods=days).sum()
    features["temperature_mean_prev7d_c"]=w.temperature_mean_c.shift(2).rolling(7,min_periods=7).mean()
    features["positive_degree_days_prev7d"]=w.temperature_mean_c.clip(lower=0).shift(2).rolling(7,min_periods=7).sum()
    features["feature_window_end_utc"]=(features.index-pd.Timedelta(days=1)).strftime("%Y-%m-%dT00:00:00Z")
    features["day_of_year_sin"]=np.sin(2*np.pi*(features.index.day_of_year-1)/365.2425)
    features["day_of_year_cos"]=np.cos(2*np.pi*(features.index.day_of_year-1)/365.2425)
    features["weather_series_id"]="power_regional_43.1_77.08"
    return features,w


def split(d):
    return np.where(d.dt.year<=2005,"train",np.where(d.dt.year<=2012,"validation","test"))


def dynamic(events,features):
    panels=[]
    eligible=events[events.exact_date_eligible & events.dedup_keep & events.country.eq("Kazakhstan")]
    for name,loc in BASINS.items():
        p=features.loc["1981-01-01":"2020-12-31"].copy().reset_index()
        p["location_id"]=loc; p["basin"]=name
        es=eligible[eligible.basin.eq(name)]
        byday=es.groupby("date_start").agg(event_ids=("event_id",lambda x:";".join(sorted(x))),
                                          event_types=("event_type",lambda x:";".join(sorted(set(x)))),
                                          event_record_count=("event_id","size"))
        p=p.merge(byday,left_on="date",right_index=True,how="left",validate="one_to_one")
        p["target"]=pd.Series(np.where(p.event_ids.notna(),1,np.nan),dtype="Float64")
        p["label_status"]=np.where(p.target.eq(1).fillna(False),"confirmed_catalogue_positive","unlabeled")
        p["date_uncertainty_overlap"]=False
        uncertain=events[events.basin.eq(name)&events.country.eq("Kazakhstan")&~events.exact_date_eligible]
        for a in uncertain.itertuples():
            # Unresolved multiple dates with a reliable year quarantine the whole year.
            if pd.notna(a.date_start) and pd.notna(a.date_end):
                mask=p.date.between(a.date_start,a.date_end)
            elif pd.notna(a.year_source) and 1981<=a.year_source<=2020:
                mask=p.date.dt.year.eq(int(a.year_source))
            else:
                continue
            p.loc[mask,"date_uncertainty_overlap"]=True
        p["feature_complete"]=p[feature_columns()].notna().all(axis=1)
        p["split"]=split(p.date)
        p["source_ids"]="reading_events;nasa_power"
        panels.append(p)
    df=pd.concat(panels,ignore_index=True).sort_values(["date","location_id"]).reset_index(drop=True)
    save(df,"model_dynamic_power")
    # Regional panel removes pseudo-replication of shared meteorological series.
    reg=df.groupby("date",as_index=False).agg(target=("target","max"),
          event_record_count=("event_record_count","sum"),
          positive_basins=("basin",lambda x:""),
          date_uncertainty_overlap=("date_uncertainty_overlap","max"))
    positive=df[df.target.eq(1).fillna(False)].groupby("date").basin.agg(lambda x:";".join(sorted(x)))
    reg["positive_basins"]=reg.date.map(positive)
    reg=reg.drop(columns="positive_basins").merge(positive.rename("positive_basins"),on="date",how="left")
    reg=reg.merge(features.reset_index(),on="date",how="left",validate="one_to_one")
    reg["label_status"]=np.where(reg.target.eq(1).fillna(False),"confirmed_catalogue_positive","unlabeled")
    reg["feature_complete"]=reg[feature_columns()].notna().all(axis=1)
    reg["split"]=split(reg.date)
    reg["source_ids"]="reading_events;nasa_power"
    save(reg,"model_regional_power")
    return df,reg


def feature_columns():
    return ["precipitation_lag2utc_mm","temperature_mean_lag2utc_c","temperature_min_lag2utc_c",
            "temperature_max_lag2utc_c","precipitation_prev3d_mm","precipitation_prev7d_mm",
            "precipitation_prev14d_mm","temperature_mean_prev7d_c","positive_degree_days_prev7d",
            "day_of_year_sin","day_of_year_cos"]


def era5(events):
    p=pd.read_csv(SRC/"legacy_model_dataset.csv")
    for col in ["target","label_status","event_id","event_type","event_source_url"]:
        p=p.drop(columns=col)
    p["date"]=pd.to_datetime(p.date)
    exact=events[events.exact_date_eligible & events.dedup_keep & events.country.eq("Kazakhstan")].copy()
    names={"Kishi Almaty":"kishi_almaty","Ulken Almaty":"ulken_almaty","Left Talgar":"left_talgar"}
    exact["location_id"]=exact.basin.map(names)
    grouped=exact.dropna(subset=["location_id"]).groupby(["date_start","location_id"]).agg(
        event_id=("event_id",lambda x:";".join(sorted(x))),
        event_type=("event_type",lambda x:";".join(sorted(set(x)))),
        event_source_url=("source_url",lambda x:";".join(sorted(set(x)))))
    p=p.merge(grouped,left_on=["date","location_id"],right_index=True,how="left",validate="one_to_one")
    p["target"]=pd.Series(np.where(p.event_id.notna(),1,np.nan),dtype="Float64")
    p["label_status"]=np.where(p.target.eq(1).fillna(False),"confirmed_catalogue_positive","unlabeled")
    p["source_ids"]="legacy_open_meteo_era5;legacy_usgs;reading_events;kazhydromet_2023"
    save(p,"model_dynamic_era5")
    original_columns=pd.read_csv(SRC/"legacy_model_dataset.csv",nrows=0).columns.tolist()
    save(p[original_columns],"model_dataset")
    return p


def main():
    events=catalogue(); n=polygons(); features,w=weather()
    dyn,reg=dynamic(events,features); era=era5(events)
    report=dict(version="0.2",built_on="2026-11-14",event_records=len(events),
        reading_records=int(events.source_id.eq("reading_events").sum()),
        country_counts=events.country.value_counts().to_dict(),
        date_precision_counts=events.date_precision.value_counts().to_dict(),
        exact_day_records=int(events.exact_date_eligible.sum()),
        date_year_conflicts=events.loc[events.date_year_conflict,"event_id"].tolist(),
        possible_duplicate_rows=int(events.possible_duplicate.sum()),
        polygon_count=n,weather_daily_rows=len(w),
        weather_start=str(w.index.min().date()),weather_end=str(w.index.max().date()),
        weather_missing_cells=int(w[["precipitation_mm","temperature_mean_c","temperature_min_c","temperature_max_c"]].isna().sum().sum()),
        strict_true_negatives=0)
    for key,p in [("dynamic_power",dyn),("regional_power",reg),("dynamic_era5",era)]:
        report[key]=dict(rows=len(p),positives=int(p.target.eq(1).sum()),unknown=int(p.target.isna().sum()),
            unique_positive_dates=int(p.loc[p.target.eq(1),"date"].nunique()),
            split_counts={str(k):{"rows":len(g),"positives":int(g.target.eq(1).sum())}
                          for k,g in p.groupby("split")})
    (META/"quality_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2))
    allow={"dynamic_power":feature_columns()+["location_id"],
           "regional_power":feature_columns(),
           "dynamic_era5":[c for c in era.columns if c.startswith(("temperature_","precipitation_","rain_","snowfall_","soil_","snow_depth","earthquake_","day_of_year_"))]}
    (META/"feature_allowlist.json").write_text(json.dumps(allow,indent=2))
    # Schema is exhaustive: one row for every output table column.
    schemas=[]
    for p in sorted(DATA.glob("*.parquet")):
        d=pd.read_parquet(p)
        for c in d:
            schemas.append(dict(table=p.stem,column=c,dtype=str(d[c].dtype),
                                missing=int(d[c].isna().sum()),example=str(d[c].dropna().iloc[0]) if d[c].notna().any() else ""))
    pd.DataFrame(schemas).to_csv(META/"schema.csv",index=False)
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
