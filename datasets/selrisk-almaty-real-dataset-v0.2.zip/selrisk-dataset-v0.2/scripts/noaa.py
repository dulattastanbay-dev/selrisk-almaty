"""Parse original GHCN-Daily fixed-width values AND flags, with no gap filling."""
import calendar
import json
import numpy as np
import pandas as pd

from build import ROOT, SRC, META, DATA, BASINS, save

STATIONS = ["KZ000036870","KZ000036879","KZ000036889","KZ000036884","KZ000036887"]


def main():
    inventory = {}
    for line in (SRC/"ghcnd-stations.txt").read_text().splitlines():
        if line[:11] in STATIONS:
            inventory[line[:11]]=dict(station_id=line[:11],latitude=float(line[12:20]),
               longitude=float(line[21:30]),elevation_m=float(line[31:37]),
               name=line[41:71].strip(),
               source_url="https://www.ncei.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt",
               coordinate_accuracy="as_published_in_GHCNd_not_survey_accuracy")
    save(pd.DataFrame(inventory.values()),"weather_stations")
    rows=[]
    for p in sorted((SRC/"noaa").glob("*.dly")):
        for line in p.read_text().splitlines():
            station=line[:11]; y=int(line[11:15]); m=int(line[15:17]); element=line[17:21]
            if element not in ["PRCP","TMAX","TMIN","TAVG","SNWD"]:
                continue
            for day in range(1,calendar.monthrange(y,m)[1]+1):
                raw=line[21+(day-1)*8:21+day*8].ljust(8)
                value=int(raw[:5]); measurement,quality,source=raw[5:8]
                missing=value==-9999
                passed=not quality.strip() and not missing
                unit="mm" if element in ["PRCP","SNWD"] else "degC"
                factor=1 if element=="SNWD" else 10
                rows.append(dict(date=pd.Timestamp(y,m,day),station_id=station,element=element,
                    raw_value=value,measurement_flag=measurement.strip(),quality_flag=quality.strip(),
                    source_flag=source.strip(),qa_passed=passed,value=value/factor if passed else np.nan,
                    unit=unit,source_id="noaa_ghcnd",
                    source_url=f"https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/{station}.dly"))
    df=pd.DataFrame(rows)
    assert not df.duplicated(["date","station_id","element"]).any()
    save(df,"weather_noaa_observations")
    # Do not turn PRCP-only high-mountain stations into full temperature stations.
    coverage=df.groupby(["station_id","element"]).agg(first_date=("date","min"),last_date=("date","max"),
               rows=("date","size"),qa_usable=("qa_passed","sum")).reset_index()
    coverage.to_csv(META/"noaa_coverage.csv",index=False)
    e=pd.read_parquet(DATA/"event_catalogue.parquet")
    e["date_start"]=pd.to_datetime(e.date_start)
    e["date_end"]=pd.to_datetime(e.date_end)
    es=e[e.exact_date_eligible & e.dedup_keep & e.country.eq("Kazakhstan") & e.basin.isin(BASINS)]
    dates=pd.date_range("1937-01-01","1991-12-31",name="date")
    p=pd.DataFrame(index=dates)
    # Regional multi-station rainfall representation; no artificial basin assignment.
    used={"mynzhylki":"KZ000036889","bao":"KZ000036879","gorelnik":"KZ000036887","almaty":"KZ000036870"}
    allow=[]
    for name,station in used.items():
        rain=df[(df.station_id==station)&df.element.eq("PRCP")].set_index("date").value
        rain=rain.reindex(pd.date_range("1936-12-01","1991-12-31"))
        for days in [1,3,7,14]:
            col=f"{name}_precipitation_prev{days}d_lag2_mm"
            p[col]=rain.shift(2).rolling(days,min_periods=days).sum()
            allow.append(col)
    p["day_of_year_sin"]=np.sin(2*np.pi*(p.index.day_of_year-1)/365.2425)
    p["day_of_year_cos"]=np.cos(2*np.pi*(p.index.day_of_year-1)/365.2425)
    allow+=["day_of_year_sin","day_of_year_cos"]
    grouped=es.groupby("date_start").agg(event_ids=("event_id",lambda x:";".join(sorted(x))),
         positive_basins=("basin",lambda x:";".join(sorted(set(x)))),
         event_types=("event_type",lambda x:";".join(sorted(set(x)))))
    p=p.join(grouped)
    p["target"]=np.where(p.event_ids.notna(),1,np.nan)
    p["label_status"]=np.where(p.target.eq(1),"confirmed_catalogue_positive","unlabeled")
    p["date_uncertainty_overlap"]=False
    for a in e[~e.exact_date_eligible & e.country.eq("Kazakhstan") & e.basin.isin(BASINS)].itertuples():
        if pd.notna(a.date_start) and pd.notna(a.date_end):
            mask=(p.index>=a.date_start)&(p.index<=a.date_end)
        elif pd.notna(a.year_source) and 1937<=a.year_source<=1991:
            mask=p.index.year==int(a.year_source)
        else:
            continue
        p.loc[mask,"date_uncertainty_overlap"]=True
    p["feature_complete"]=p[allow].notna().all(axis=1)
    p["feature_window_last_observation_date"]=(p.index-pd.Timedelta(days=2)).strftime("%Y-%m-%d")
    p["split"]=np.where(p.index.year<=1973,"train",np.where(p.index.year<=1981,"validation","test"))
    p["source_ids"]="noaa_ghcnd;reading_events"
    save(p.reset_index(),"model_regional_stations")
    allowpath=META/"feature_allowlist.json"
    obj=json.loads(allowpath.read_text()); obj["regional_stations"]=allow
    allowpath.write_text(json.dumps(obj,indent=2))
    report=dict(observation_rows=len(df),qa_usable=int(df.qa_passed.sum()),
        station_count=len(inventory),regional_rows=len(p),regional_positives=int(p.target.eq(1).sum()),
        complete_feature_rows=int(p.feature_complete.sum()),
        complete_feature_positives=int((p.target.eq(1)&p.feature_complete).sum()),
        split_counts={k:dict(rows=len(g),positives=int(g.target.eq(1).sum()),
                      complete_positives=int((g.target.eq(1)&g.feature_complete).sum())) for k,g in p.groupby("split")})
    (META/"noaa_quality_report.json").write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
